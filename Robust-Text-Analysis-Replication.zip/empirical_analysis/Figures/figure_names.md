The empirical exercise plots are stored in empirical_analysis/Figures. The file names for graphs in the paper are: 

* Figure 9(a): prior_alpha_1.25_beta_0.025_percent_diff.eps

* Figure 9(b): posterior_alpha_1.25_beta_0.025_percent_diff.eps

* Figure 7(a) in online appendix: prior_alpha_1.25_beta_0.025_regression.eps
* Figure 7(b) in online appendix:  posterior_alpha_1.25_beta_0.025_regression.eps
* Figure 8(a) in online appendix: prior_alpha_1_beta_1_percent_diff.eps

* Figure 8(b) in online appendix: posterior_alpha_1_beta_1_percent_diff.eps
* Figure 9(a) in online appendix: prior_alpha_1_beta_1_regression.eps

* Figure 9(b) in online appendix: posterior_alpha_1_beta_1_regression.eps
* Figure 8(a) in online appendix: prior_alpha_1.25_beta_0.025_percent_diff_FOMC2.eps
* Figure 8(b) in online appendix: posterior_alpha_1.25_beta_0.025_percent_diff_FOMC2.eps
* Figure 9(a) in online appendix: prior_alpha_1.25_beta_0.025_regression_FOMC2.eps
* Figure 9(b) in online appendix: posterior_alpha_1.25_beta_0.025_regression_FOMC2.eps