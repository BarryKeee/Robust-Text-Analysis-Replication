clear all
clc

N = 10; 
I_sim = 1000; 
Approximate_Range(N, I_sim)

N = 100; 
I_sim = 1000; 
Approximate_Range(N, I_sim)
